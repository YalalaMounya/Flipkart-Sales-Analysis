import pandas as pd
df = pd.read_csv("C:/Users/YALALA MOONYA/Downloads/flipkart_sales_dataset.csv")
print(df.head())
print(df.tail())
print(df.describe())
print(df.info())

import matplotlib.pyplot as plt



# -------------------------------
# 1. SALES TREND OVER TIME
# -------------------------------
df["OrderDate"] = pd.to_datetime(df["OrderDate"])

monthly_sales = df.groupby(df["OrderDate"].dt.to_period("M"))["SalesAmount"].sum()

plt.figure(figsize=(12,6))
plt.plot(monthly_sales.index.astype(str), monthly_sales.values)
plt.title("Monthly Sales Trend")
plt.xlabel("Month")
plt.ylabel("Total Sales")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# -------------------------------
# 2. SALES BY CATEGORY
# -------------------------------
category_sales = df.groupby("Category")["SalesAmount"].sum()

plt.figure(figsize=(10,6))
category_sales.plot(kind="bar")
plt.title("Sales by Category")
plt.ylabel("Sales Amount")
plt.xlabel("Category")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# -------------------------------
# 3. TOP 10 SELLING PRODUCTS
# -------------------------------
top_products = df.groupby("Product")["SalesAmount"].sum().sort_values(ascending=False).head(10)

plt.figure(figsize=(12,6))
top_products.plot(kind="bar")
plt.title("Top 10 Products by Sales")
plt.ylabel("Sales Amount")
plt.xlabel("Product")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# -------------------------------
# 4. REGION-WISE SALES
# -------------------------------
region_sales = df.groupby("Region")["SalesAmount"].sum()

plt.figure(figsize=(8,6))
region_sales.plot(kind="pie", autopct='%1.1f%%')
plt.title("Sales Distribution by Region")
plt.ylabel("")
plt.show()

# -------------------------------
# 5. DISCOUNT vs SALES SCATTER PLOT
# -------------------------------
plt.figure(figsize=(8,6))
plt.scatter(df["Discount(%)"], df["SalesAmount"])
plt.title("Discount vs Sales Amount")
plt.xlabel("Discount (%)")
plt.ylabel("Sales Amount")
plt.show()
